LINE is written and maintained by Taehoon Kim and
various contributors:

Development Lead
````````````````

- Taehoon Kim <carpedm20@gmail.com> `@carpedm20 <https://github.com/carpedm20>`_


Core Contributors
`````````````````

- Shinz Natkid `shinznatkid <https://github.com/shinznatkid>`_
- Wittawat Tantisiriroj <wtantisiriroj@gmail.com>
- HanShen Huang <hanshenh@gmail.com>
