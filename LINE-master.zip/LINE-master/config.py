REDIS_HOST     = 'localhost'
REDIS_PORT     = 6379
REDIS_DB       = 0
REDIS_PASSWORD = None

DEBUG          = True
COMMAND_PREFIX = '!'


